/*
Author Name : Aravinth S
prject Name : Pizzahut Sales Analysis
*/
-------------------------------------------------------------------------------------------------------------------------

CREATE SCHEMA PIZZAHUT;
USE PIZZAHUT;

SELECT * FROM PIZZAS;
SELECT * FROM PIZZA_TYPES ;
SELECT * FROM ORDERS;
SELECT * FROM ORDER_DETAILS;

--------------------------------------------------------------------------------------------------------------------------


/*Retrieve the total number of orders placed.*/

SELECT COUNT(*) AS TOTAL_ORDERS FROM ORDERS;

-------------------------------------------------------------------------------------------------------------------------


/*Calculate the total revenue generated from pizza sales.*/


SELECT SUM(A.PRICE) AS TOTAL_REVENUE FROM (
SELECT OD.*, (OD.QUANTITY * P.PRICE) AS PRICE FROM ORDER_DETAILS AS OD
LEFT JOIN PIZZAS AS P ON OD.PIZZA_ID = P.PIZZA_ID) A;

---------------------------------------------------------------------------------------------------------------------------


/*Identify the highest-priced pizza.*/

SELECT P.PIZZA_ID,PT.NAME,P.PRICE FROM PIZZAS AS P
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID = PT.PIZZA_TYPE_ID
ORDER BY P.PRICE DESC LIMIT 1;

-----------------------------------------------------------------------------------------------------------------------------


/*Identify the most common pizza size ordered.*/

SELECT P.SIZE,COUNT(*) AS COUNT FROM ORDER_DETAILS AS OD
LEFT JOIN PIZZAS AS P ON OD.PIZZA_ID = P.PIZZA_ID
GROUP BY SIZE ORDER BY COUNT DESC LIMIT 1 ;

----------------------------------------------------------------------------------------------------------------------------


/*List the top 5 most ordered pizza types along with their quantities*/

SELECT P.PIZZA_TYPE_ID,PT.NAME,SUM(QUANTITY) AS QUANTITY FROM PIZZAS AS P
LEFT JOIN ORDER_DETAILS AS OD ON P.PIZZA_ID = OD.PIZZA_ID
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID = PT.PIZZA_TYPE_ID
GROUP BY PIZZA_TYPE_ID ORDER BY QUANTITY DESC LIMIT 5;

------------------------------------------------------------------------------------------------------------------------------


/*Join the necessary tables to find the total quantity of each pizza category ordered.*/

SELECT PT.CATEGORY,SUM(QUANTITY) AS QUANTITY FROM PIZZAS AS P
LEFT JOIN ORDER_DETAILS AS OD ON P.PIZZA_ID = OD.PIZZA_ID
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID = PT.PIZZA_TYPE_ID
GROUP BY PT.CATEGORY ORDER BY QUANTITY DESC;

-----------------------------------------------------------------------------------------------------------------------------------


/*Determine the distribution of orders by hour of the day.*/

SELECT HOUR(TIME)AS TIME,COUNT(ORDER_ID) AS COUNT
FROM ORDERS
GROUP BY 1
ORDER BY 1,2;

----------------------------------------------------------------------------------------------------------------------------------------


/*Join relevant tables to find the category-wise distribution of pizzas.*/

SELECT CATEGORY, COUNT(PIZZA_TYPE_ID) FROM PIZZA_TYPES
GROUP BY CATEGORY;

-----------------------------------------------------------------------------------------------------------------------------------------


/*Join relevant tables to find the category-wise distribution of orders.*/

SELECT PT.CATEGORY, COUNT(DISTINCT OD.ORDER_ID) FROM ORDER_DETAILS AS OD
LEFT JOIN PIZZAS AS P ON OD.PIZZA_ID = P.PIZZA_ID
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID = PT.PIZZA_TYPE_ID
GROUP BY PT.CATEGORY
ORDER BY 2;

-------------------------------------------------------------------------------------------------------------------------------------------


/*Group the orders by date and calculate the average number of pizzas ordered per day.*/

SELECT ROUND(AVG(COUNT_BY_DATE),0) AS AVG_NO_OF_PIZZA
FROM(
		SELECT DATE , COUNT(ORDER_ID) AS COUNT_BY_DATE FROM ORDERS GROUP BY DATE
) A;

-------------------------------------------------------------------------------------------------------------------------------------------


/*Determine the top 3 most ordered pizza types based on revenue.*/


SELECT P.PIZZA_ID,P.PIZZA_TYPE_ID,PT.NAME,SUM((P.PRICE * OD.QUANTITY)) AS REVENUE FROM PIZZAS AS P
INNER JOIN ORDER_DETAILS AS OD ON P.PIZZA_ID = OD.PIZZA_ID
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID =  PT.PIZZA_TYPE_ID
GROUP BY 3
ORDER BY 4 DESC
LIMIT 3;

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


/*Calculate the percentage contribution of each pizza type to total revenue.*/


WITH CTE AS (SELECT P.*,ROUND(SUM(P.REVENUE) OVER (ORDER BY P.REVENUE DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING),2) AS TOTAL_REVENUE FROM
(
SELECT P.PIZZA_ID,P.PIZZA_TYPE_ID,PT.NAME,SUM((P.PRICE * OD.QUANTITY)) AS REVENUE FROM PIZZAS AS P
INNER JOIN ORDER_DETAILS AS OD ON P.PIZZA_ID = OD.PIZZA_ID
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID =  PT.PIZZA_TYPE_ID
GROUP BY 3
ORDER BY 4 DESC)P)

SELECT PIZZA_ID,PIZZA_TYPE_ID,NAME ,ROUND((REVENUE/TOTAL_REVENUE) * 100,2) AS PERCENTAGE
FROM CTE;

-----------------------------------------------------------------------------------------------------------------------------------------------------------------


/*Analyze the cumulative revenue generated over time.*/


SELECT A.DATE , A.REVENUE , ROUND(SUM(A.REVENUE) OVER (ORDER BY DATE ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),2) AS CUMMULATIVE_REVENUE
FROM (
SELECT O.DATE,ROUND(SUM(OD.QUANTITY * P.PRICE),2) AS REVENUE FROM ORDERS AS O
INNER JOIN ORDER_DETAILS AS OD ON O.ORDER_ID = OD.ORDER_ID
LEFT JOIN PIZZAS AS P ON OD.PIZZA_ID = P.PIZZA_ID
GROUP BY 1
) A;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------


/*Determine the top 3 most ordered pizza types based on revenue for each pizza category.*/

SELECT CATEGORY,NAME,REVENUE
FROM(
SELECT A.CATEGORY,A.PIZZA_ID, A.PIZZA_TYPE_ID,A.NAME,A.REVENUE, ROW_NUMBER() OVER (PARTITION BY CATEGORY ORDER BY REVENUE DESC) AS RNK
FROM (
SELECT P.PIZZA_ID,P.PIZZA_TYPE_ID,PT.NAME,PT.CATEGORY,SUM((P.PRICE * OD.QUANTITY)) AS REVENUE FROM PIZZAS AS P
INNER JOIN ORDER_DETAILS AS OD ON P.PIZZA_ID = OD.PIZZA_ID
LEFT JOIN PIZZA_TYPES AS PT ON P.PIZZA_TYPE_ID =  PT.PIZZA_TYPE_ID
GROUP BY 3)A)B
WHERE RNK <= 3;


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


